
# TypeScript API with TypeORM

## Run this project

- Install the dependencies:
```
yarn
```
- Run the app:
```
yarn start:dev
```
## Build and Run
- Install the dependencies:
```
yarn
```
- Build and run the app:
```
yarn build
yarn start:prod
```
