  export interface BarInterface {
    _id:string;
    name:String;
    vibes:String;
    score:Number;
    nVotes:Number;
    petFriendly:number;
    ownerID:String;
    adr:String;
  }


  export interface UserInterface {
    _id:String;
    username:String;
  }


  export interface OwnerInterface extends UserInterface {
    owner:String;
    username:String;
  }

  export interface RewieInterface {
    _id?:String;
    username?:String;
    userId?:String;
    text:String;
    placeId?:String;
  }
