import React from 'react'
import { BarInterface } from '../../interface'
import * as S from './styles'
import { useNavigate } from 'react-router-dom'

function Bar({bar}:{bar:BarInterface}) {
  const navigate = useNavigate();

  return (
    <S.Bar onClick={() => navigate('/barprofile/'+bar._id)}>{bar.name}</S.Bar>
  )
}

export default Bar