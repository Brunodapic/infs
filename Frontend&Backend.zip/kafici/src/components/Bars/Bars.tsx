import React from "react";
import { BarInterface } from "../../interface";
import Bar from "./Bar";
import * as S from './styles'


function Bars({ bars }: { bars: BarInterface[] }) {
    console.log(bars)
  return (
    <S.BarWrapperDiv>
      <h3>Bars</h3>

      {bars && bars.length >0  && bars.map((bar: BarInterface) => {
        return <Bar key={JSON.stringify(bar)} bar={bar} />;
      })}
    </S.BarWrapperDiv>
  );
}

export default Bars;
