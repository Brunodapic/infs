import styled from "styled-components";

export const Bar = styled.div`
  display: flex;
  justify-content: center;
  border: 2px solid white;
  padding: 10px;
  background-color: #0a6bff;
  cursor: pointer;
  height: 100px;
  border-radius: 8px;

  button {
    background-color: #0a6bff;
    border-radius: 4px;
    border: 0;
    box-shadow: rgba(1, 60, 136, 0.5) 0 -1px 3px 0 inset,
      rgba(0, 44, 97, 0.1) 0 3px 6px 0;
    box-sizing: border-box;
    color: #fff;
    cursor: pointer;
    display: inherit;
    font-family: "Space Grotesk", -apple-system, system-ui, "Segoe UI", Roboto,
      Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji",
      "Segoe UI Symbol";
    font-size: 12px;
    font-weight: 400;
    line-height: 18px;
    margin: 5px;
    min-height: 20px;
    min-width: 120px;
    padding: 5px 5px;
    position: relative;
    text-align: center;
    user-select: none;
    -webkit-user-select: none;
    touch-action: manipulation;
    vertical-align: baseline;
    transition: all 0.2s cubic-bezier(0.22, 0.61, 0.36, 1);
  }
  
  
  &:hover {
    background-color: #0affff;
    transform: translateY(-2px);
  }
`;

export const BarWrapperDiv = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  color: black;
  cursor: pointer;
  margin: auto;
  width: 70%;
  padding: 10px;
`;
