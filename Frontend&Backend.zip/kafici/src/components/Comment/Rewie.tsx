import React, { useState } from "react";
import { RewieInterface } from "../../interface";
import * as S from "./styles";
import AddRewie from "./AddRewie";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";

function Rewie({ rewie,deleteRewie,updateRewie }: { rewie: RewieInterface,deleteRewie:(rewie: RewieInterface)=>void,updateRewie:(rewie: RewieInterface)=>void }) {

  const navigate = useNavigate();

  const [del,setDel]=useState(true)
  const [update,setUpdate]=useState(false)

  const [updatedFlag,setUpdatedFlag] = useState(false)

  const [updated,setUpdated] = useState("")


  const deleteButton = ()=>{
    setDel(false)
    deleteRewie(rewie)
  }


  const updateButton = ()=>{
    setDel(!del)
    setUpdate(!update)
    //
  }


  const edditRewie = (text:string)=>{
    setUpdatedFlag(true)
    setUpdated(text)
    setDel(!del)
    setUpdate(!update)
    updateRewie(rewie)
  }

 
  return (
    <>
    {del &&
     <S.Comment >
      <Link to={`../../user/${rewie.userId}`}>
              <h4 style={{ margin: "10px" }}>Username: {rewie.username}</h4>

      </Link>
      <h4 style={{ margin: "10px" }}>Rewie: {updatedFlag?updated:rewie.text}</h4>
      {rewie.userId === localStorage.getItem("userId") && (
        <S.ButtonsDiv>
          <button onClick={()=>deleteButton()}>Delete</button>
          <button onClick={()=>updateButton()}>Edit</button>
        </S.ButtonsDiv>
      )}
    </S.Comment>
    }
    {update &&
     <AddRewie submitRewie={edditRewie} />
    }
    </>
   
  );
}

export default Rewie;
