import React, { useState } from "react";
import * as S from "./styles";

function AddRewie({submitRewie}:{submitRewie:(text:any)=>void}) {

    const [text,setText]=useState<any>("")

    const handleChange = (event:any) =>{
        setText(event.target.value)
    }

    const submit = ()=>{

        submitRewie(text)
        setText("")
    }

  return (
      <S.AddRewieDiv>
        <S.AddRewieBox value={text} onChange={handleChange}/>
        <button onClick={()=>submit()}>Submit</button>
      </S.AddRewieDiv>
  );
}

export default AddRewie;
