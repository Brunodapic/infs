import styled from "styled-components";

export const Comment = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  border: 2px solid #0a6bff;
  padding: 10px;
  height: 100px;
  border-radius: 8px;

  button {
    background-color: #0a6bff;
    border-radius: 4px;
    border: 0;
    box-shadow: rgba(1, 60, 136, 0.5) 0 -1px 3px 0 inset,
      rgba(0, 44, 97, 0.1) 0 3px 6px 0;
    box-sizing: border-box;
    color: #fff;
    cursor: pointer;
    display: inherit;
    font-family: "Space Grotesk", -apple-system, system-ui, "Segoe UI", Roboto,
      Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji",
      "Segoe UI Symbol";
    font-size: 12px;
    font-weight: 400;
    line-height: 18px;
    margin: 5px;
    min-height: 20px;
    min-width: 120px;
    padding: 5px 5px;
    position: relative;
    text-align: center;
    user-select: none;
    -webkit-user-select: none;
    touch-action: manipulation;
    vertical-align: baseline;
    transition: all 0.2s cubic-bezier(0.22, 0.61, 0.36, 1);
  }

  &:hover {
    background-color: lightgray;
    transform: translateY(-2px);
  }
`;

export const CommentWrapperDiv = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  color: black;
  cursor: pointer;
  margin: auto;
  width: 70%;
  padding: 10px;
`;

export const AddRewieDiv = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  border: 2px solid #0a6bff;
  padding: 10px;
  height: 100px;
  border-radius: 8px;
`;

export const AddRewieBox = styled.textarea`
  width: 100%;
  min-height: 90px;
  -webkit-box-sizing: border-box; /* Safari/Chrome, other WebKit */
  -moz-box-sizing: border-box; /* Firefox, other Gecko */
  box-sizing: border-box; /* Opera/IE 8+ */
`;

export const ButtonsDiv = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  text-align: center;
`;
