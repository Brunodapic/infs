import React, { useState } from "react";
import { RewieInterface } from "../../interface";
import Rewie from "./Rewie";
import * as S from "./styles";
import AddRewie from "./AddRewie";
import axios from "axios";

function RewiesWrapper({
  rewies,
  barId,
}: {
  rewies: RewieInterface[];
  barId: string;
}) {
  const [addRewie, setRewie] = useState(false);

  const [newRewies, setNewRewies] = useState<RewieInterface[]>([]);

  const submitRewie = (text: string) => {
    const sendData = {
      username: localStorage.getItem("username"),
      userId: localStorage.getItem("userId"),
      text: text,
    };
    axios
      .post("http://localhost:3333/rewies/" + barId, sendData)
      .then(function (response) {
        console.log(response);
      })
      .catch(function (error) {
        console.log("ERROR");
      });

    setRewie(false);
    console.log(text);


    //@ts-ignore
    setNewRewies((current) => [...current, sendData]);
  };


  const deleteRewie = (rewie: RewieInterface) => {
    console.log("delete")
    const sendData = {
      username: localStorage.getItem("username"),
      userId: localStorage.getItem("userId"),
    };
    console.log(rewie)
    axios
      .delete("http://localhost:3333/rewies/" + barId, { data: rewie })
      .then(function (response) {
        console.log(response);
      })
      .catch(function (error) {
        console.log("ERROR");
      });

  };

  const updateRewie = (rewie: RewieInterface) => {
    console.log("update")
    
    console.log(rewie)
    axios
      .put("http://localhost:3333/rewies/" + barId, { data: rewie })
      .then(function (response) {
        console.log(response);
      })
      .catch(function (error) {
        console.log("ERROR");
      });

  };

  return (
    <S.CommentWrapperDiv>
      <h3>Rewies</h3>
      <button onClick={() => setRewie(!addRewie)}>
        {addRewie ? "Cancel Rewie" : "Add Rewie"}
      </button>
      <br />

      {addRewie && <AddRewie submitRewie={submitRewie} />}

      {newRewies &&
        newRewies.map((rewie) => {
          return <Rewie key={JSON.stringify(rewie.text)} rewie={rewie} deleteRewie={deleteRewie} updateRewie={updateRewie}/>;
        })}

      {rewies &&
        rewies.map((rewie) => {
          return <Rewie key={JSON.stringify(rewie._id)} rewie={rewie} deleteRewie={deleteRewie} updateRewie={updateRewie}/>;
        })}
    </S.CommentWrapperDiv>
  );
}

export default RewiesWrapper;
