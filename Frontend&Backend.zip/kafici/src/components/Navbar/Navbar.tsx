import { useNavigate } from "react-router-dom";
import * as S from "./styles";

export default function NavBar() {
  const navigate = useNavigate();

  const logout = ()=>{
    localStorage.clear();
    navigate("/")
  }
  return (
    <S.navigationBar>
      <button onClick={() => navigate("/")}>Home</button>
      {localStorage.getItem("userId") && (
          <button onClick={() => navigate("/user/"+localStorage.getItem("userId"))}>Profile</button>
        )}
      
     
      <S.usernameDisplayDiv>
        {localStorage.getItem("username") ? (
          <h3 onClick={()=>logout()}>{localStorage.getItem("username")}</h3>
        ) : (
          <h3 onClick={()=>navigate("/login")}>Login</h3>
        )}
      </S.usernameDisplayDiv>
    </S.navigationBar>
  );
}
