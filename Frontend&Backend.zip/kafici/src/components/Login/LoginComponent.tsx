import { useNavigate } from "react-router-dom";
import * as React from "react";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import { createTheme } from "@mui/material/styles";
import { useState } from "react";
import axios from "axios";

const theme = createTheme();

export default function LoginComponent() {
  let navigate = useNavigate();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false);

  const usernameValidation = username.length < 300 && username.length > 2;

  var passwordError = "";
  const validatePasswor = () => {
    /*
    if (password.length < 8) {
      passwordError = "Your password must be at least 8 characters";
    }
    if (password.search(/[a-z]/i) < 0) {
      passwordError = "Your password must contain at least one letter.";
    }
    if (password.search(/[0-9]/) < 0) {
      passwordError = "Your password must contain at least one digit.";
    }
    if (password.search(/[!@#\$%\^&\*_]/) < 0) {
      passwordError =
        "Your password must contain at least one special character (+,-,!,#,$).";
    }
    */
    if (passwordError == "") {
      return false;
    }
    return true;
  };

  const passwordChange = (event: any) => {
    setPassword(event.target.value);
  };
  const usernameChange = (event: any) => {
    setUsername(event.target.value);
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const loginData = {
      username: username,
      password: password,
    };


    if (validatePasswor()) {
      setError(true);
    } else {
      axios
        .post(
          "http://localhost:3333/login",
          loginData
        )
        .then(function (response) {
          localStorage.setItem("userId", response.data.findUser._id);
          localStorage.setItem("username", response.data.findUser.username);

          navigate("/");
        })
        .catch(function (error) {
          setUsername("");
          setPassword("");
          alert("Wrong login info");
        });
    }
  };

  return (
    <div
      style={{
        height: "100vh",
        backgroundRepeat: "no-repeat",
        backgroundSize: "cover",
        display: "flex",
        alignItems: "center",
      }}
    >
      <Container
        component="main"
        maxWidth="xs"
        sx={{
          display: "flex",
          padding: "2rem",
          color: "black",
        }}
      >
        <CssBaseline />
        <Box
          sx={{
            marginTop: 8,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            backgroundColor: "white",
            padding: "2rem",
            color: "black",
          }}
        >
          <Typography component="h1" variant="h5" color="black">
            Login in
          </Typography>
          <Box
            component="form"
            onSubmit={handleSubmit}
            noValidate
            sx={{ mt: 1 }}
          >
            <TextField
              margin="normal"
              required
              fullWidth
              id="username"
              label="username"
              name="username"
              autoComplete="username"
              autoFocus
              value={username}
              onChange={usernameChange}
              error={error && !usernameValidation}
              helperText={error && !usernameValidation ? "Eneter valid username" : ""}
            />
            <TextField
              margin="normal"
              required
              fullWidth
              name="password"
              label="Password"
              type="password"
              id="password"
              autoComplete="current-password"
              value={password}
              onChange={passwordChange}
              error={error && validatePasswor()}
              helperText={error && validatePasswor() ? passwordError : ""}
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2, backgroundColor: "#40E0D0", color: "white" }}
              
            >
              Log In
            </Button>
          </Box>
        </Box>
      </Container>
    </div>
  );
}