import axios from "axios";
import React, { useEffect, useState } from "react";
import Bars from "../../components/Bars/Bars";
import { BarInterface } from "../../interface";

function Home() {
  const [bars, setBars] = useState<BarInterface[]>([]);
  console.log(bars);

  async function getBars() {
    axios
      .get("http://localhost:3333")
      .then((res) => {
        setBars(res.data.findBars);
      })
      .catch((error) => {
        console.error(error);
      });
  }
  useEffect(() => {
    getBars();
  }, []);

  return (
    <div style={{display:'flex',flexDirection:'column'}}>
      Home
      <Bars bars={bars} />
    </div>
  );
}

export default Home;
