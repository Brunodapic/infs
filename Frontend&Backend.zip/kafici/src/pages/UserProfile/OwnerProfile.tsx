import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { BarInterface, OwnerInterface } from "../../interface";
import axios from "axios";
import Bars from "../../components/Bars/Bars";

function OwnerProfile() {
  const { ownerId } = useParams();

  const [ownerData, setownerData] = useState<OwnerInterface>();
  const [bars, setBars] = useState<BarInterface[]>([]);
    
  console.log(ownerData);
  console.log(bars);
  async function getownerData() {
    axios
      .get("http://localhost:3333/owner/" + ownerId)
      .then((res) => {
        console.log(res.data);
        setownerData(res.data.findOwner);
        setBars(res.data.findOwnersBars);
      })
      .catch((error) => {
        console.error(error);
      });
  }
  useEffect(() => {
    getownerData();
  }, []);

  return (
    <div>
      Owner Profile
      <div>
        <h3>{ownerData?._id}</h3>
        <h2>{ownerData?.username}</h2>

        {bars && bars.length > 0 ? (
          <Bars bars={bars} />
        ) : (
          <div>Owner owns no bars</div>
        )}
      </div>
    </div>
  );
}

export default OwnerProfile;
