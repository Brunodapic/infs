import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { BarInterface, UserInterface } from "../../interface";
import axios from "axios";

function BarProfile() {
  const { userId } = useParams();

  const [userData, setUserData] = useState<UserInterface>();
  console.log(userData);
  async function getUserById() {
    axios
      .get("http://localhost:3333/user/" + userId)
      .then((res) => {
        setUserData(res.data.findUser);
      })
      .catch((error) => {
        console.error(error);
      });
  }
  useEffect(() => {
    getUserById();
  }, []);

  return <div>User Id
    <div>
        <h3>{userData?._id}</h3>
        <h2>{userData?.username}</h2>


    </div>
  </div>;
}

export default BarProfile;
