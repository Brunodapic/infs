import React from 'react'
import LoginComponent from '../../components/Login/LoginComponent'

function Login() {
  return (
    <div>
        <LoginComponent />
    </div>
  )
}

export default Login