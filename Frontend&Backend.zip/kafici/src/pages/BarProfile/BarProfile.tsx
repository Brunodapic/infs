import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { BarInterface, RewieInterface } from "../../interface";
import axios from "axios";
import RewiesWrapper from "../../components/Comment/RewiesWrapper";

function BarProfile() {
  const navigate = useNavigate();
  const { barId } = useParams();

  const [barData, setBarData] = useState<BarInterface>();
  const [rewies, setRewies] = useState<RewieInterface[]>([]);

  console.log(barData);
  console.log(rewies);

  async function getBarById() {
    axios
      .get("http://localhost:3333/bar/" + barId)
      .then((res) => {
        setBarData(res.data.findBar);
        setRewies(res.data.findRewies);
      })
      .catch((error) => {
        console.error(error);
      });
  }

  useEffect(() => {
    getBarById();
  }, []);

  return (
    <div>
      BarProfile
      <div>
        <h3>{barData?._id}</h3>
        <h2>{barData?.adr}</h2>
        <h2>{barData?.name}</h2>
        <h2>{barData?.petFriendly}</h2>
        <h2>{JSON.stringify(barData?.score)}</h2>
        <h2>{barData?.vibes}</h2>
        <Link to={`../../owner/${barData?.ownerID}`}>
          <h2>Check out owner profile</h2>
        </Link>
      </div>
      <div
        style={{
          border: "solid black 1px",
          padding: "1px",
          margin: "10px",
          backgroundColor: "blue",
        }}
      ></div>
      <RewiesWrapper rewies={rewies} barId={barData?._id ? barData._id : ""} />
    </div>
  );
}

export default BarProfile;
