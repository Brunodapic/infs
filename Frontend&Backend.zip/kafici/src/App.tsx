import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './pages/Home/Home';
import "./App.css";
import "./index.css";
import NavBar from './components/Navbar/Navbar';
import BarProfile from './pages/BarProfile/BarProfile';
import UserProfile from './pages/UserProfile/UserProfile';
import OwnerProfile from './pages/UserProfile/OwnerProfile';
import Login from './pages/Login/Login';

function App() {
  return (
    <div className="App">
      <Router>
        <NavBar />
        <Routes>
          <Route path="/barprofile/:barId" element={<BarProfile />} />
          <Route path="/user/:userId" element={<UserProfile />} />
          <Route path="/owner/:ownerId" element={<OwnerProfile />} />
          <Route path="/login" element={<Login />} />

          <Route path="/" element={<Home />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;